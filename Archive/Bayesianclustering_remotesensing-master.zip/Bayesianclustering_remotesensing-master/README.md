# Bayesianclustering_remotesensing
Bayesian clustering for remote sensing data
