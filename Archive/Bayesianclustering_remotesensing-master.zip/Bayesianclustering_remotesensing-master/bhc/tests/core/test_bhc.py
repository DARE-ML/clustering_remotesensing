# -*- coding: utf-8 -*-

# License: GPL 3.0

def test():
    assert True
